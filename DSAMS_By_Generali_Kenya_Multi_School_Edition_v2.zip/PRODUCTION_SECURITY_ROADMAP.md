# DSAMS Production Security & Delivery Roadmap

## Phase 1 — Governance and requirements
- Confirm the legal operator, school onboarding authority, ownership and support model.
- Validate workflows with the proposed pilot school, Gendia Boys High School, Homa Bay County.
- Define data categories, purposes, retention periods, user roles and school responsibilities.
- Obtain qualified Kenyan legal and data-protection advice; assess obligations under the Data Protection Act, 2019 and applicable regulations.
- Complete a data-protection impact assessment where required, especially for children's data and high-risk processing.

## Phase 2 — Production architecture
- Build a server-side application API and managed relational database.
- Model each school as a tenant; enforce tenant scope in server authorization and database policies.
- Ensure platform administrators cannot casually browse sensitive learner records without a logged, authorised purpose.
- Use a vetted identity provider or secure authentication implementation; enforce MFA for privileged roles.
- Store secrets in a secrets manager; never put credentials or private keys in browser code or GitHub.
- Use TLS, secure cookies, CSRF protection where applicable, input validation, output encoding, rate limiting and secure headers.

## Phase 3 — Core modules
- School onboarding and verification
- Admissions and document handling
- Student records and guardian relationships
- Staff, roles and approvals
- Attendance, academics and welfare
- Boarding and stores
- Fees, invoices and payment-provider integration
- Parent communication and notifications
- Reporting and controlled exports

## Phase 4 — Security and privacy assurance
- Threat model the platform and test tenant-boundary failures.
- Conduct independent penetration testing and vulnerability remediation.
- Encrypt sensitive data in transit and at rest; define key rotation and access procedures.
- Maintain tamper-evident audit trails for access, changes, exports and administrative actions.
- Test backups, disaster recovery, incident response and account recovery.
- Minimise collected data and implement retention, deletion, correction and data-subject request workflows.

## Phase 5 — Controlled pilot and rollout
- Use synthetic test data during development.
- Pilot with one authorised school only after security and privacy release gates pass.
- Train staff and guardians; establish support and incident escalation.
- Expand school-by-school after monitoring capacity, support and controls are proven.

## Non-negotiable
Do not use the static GitHub Pages prototype for real student records, identity documents, health data, passwords or payments. Static HTML cannot enforce secure login or school-by-school data isolation.
