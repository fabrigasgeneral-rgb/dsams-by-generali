# DSAMS by Generali — Kenya Multi-School Edition

This package contains a refreshed front-end demonstration for the DSAMS multi-school concept.

## Open the demo
Open `index.html` in a modern browser, or publish that file as the root `index.html` of a GitHub Pages repository.

## Included concept areas
- Kenya-wide school directory preview with all 47 counties
- Proposed pilot: Gendia Boys High School, Homa Bay County
- School workspace preview
- Parent/guardian admissions workflow preview
- Central administration overview
- Student, staff, attendance, academics, welfare, boarding, finance, stores and parent communication modules
- Security and data-protection blueprint

## Important limitations
This is a static front-end prototype. It does not include a production backend, real authentication, database, tenant isolation, live school onboarding, real admission submission, payment processing, or secure storage. All forms are local previews only. Do not enter real student, guardian, health, identity, password, or payment information.

GitHub Pages is suitable for hosting this static demonstration only. A production deployment needs a secure backend and database, server-enforced tenant isolation and role permissions, MFA, audit logging, encrypted backups, monitoring, privacy governance, and independent security testing.
