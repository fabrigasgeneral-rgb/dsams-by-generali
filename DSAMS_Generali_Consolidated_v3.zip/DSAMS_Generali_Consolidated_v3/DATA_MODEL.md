# DSAMS by Generali — Proposed National Data Model (Edition 3.2)

# Proposed DSAMS Data Model

- `schools`: official_code, name, county, region, category, ownership_type, onboarding_status, tenant_status
- `school_invitations`: school_id, invited_contact, token_hash, expiry, invited_by, accepted_at, status
- `users`: identity_provider_subject, verified_contacts, MFA_state, account_status
- `school_memberships`: user_id, school_id, role, permissions, status
- `guardians`: user_id, verified_contact, preferred_language
- `learners`: school_id, admission_number, learner_profile, grade_level, status
- `guardian_learner_links`: guardian_id, learner_id, relationship, access_scope, verified_at
- `academic_years`, `terms`, `learning_areas`, `CBE_pathways`, `assessment_records`
- `attendance_records`, `announcements`, `messages`, `notifications`
- `school_requirements`: school_id, category, item, description, price, required_flag, active_dates
- `invoices`: school_id, learner_id, ledger_type (`SCHOOL_FEES` or `OTHER_CHARGES`), amount, due_date, status
- `payments`: invoice_id, provider, provider_reference, amount, currency, verified_at, reconciliation_status
- `platform_fee_policy`: amount_kes, charging_interval, effective_date, disclosure_version, approval_status
- `platform_fee_transactions`: guardian_id, policy_id, amount, provider_reference, status
- `audit_events`: actor_id, school_id, action, target_type, target_id, timestamp, reason, request_id

All school-owned records must be scoped to a tenant and protected by server-side authorization. Platform fee records must be accounted for separately from school fee and other-charge ledgers.


## Additional onboarding and termly subscription entities
- `school_access_requests`: school_name, official_code, county, region, category, school_type, authorised_contact, supporting_verification_status, submitted_at, decision, decided_by, decision_reason
- `school_tenants`: school_id, tenant_key, provisioned_at, tenant_status
- `academic_terms`: academic_year, term_number, start_date, end_date, fee_due_date, grace_period_end
- `parent_term_subscriptions`: guardian_id, academic_term_id, amount_kes (20), payment_status, access_status, paid_at, receipt_id
- `payment_webhook_events`: provider_event_id, signature_verified, idempotency_key, processed_at, processing_result

Termly subscription uniqueness should be enforced for each guardian and term. School access request decisions and tenant provisioning must be auditable and performed server-side.
