# DSAMS Production Roadmap — Edition 3.2

The authoritative staged delivery plan, release gates, minimum security checklist, Gendia pilot approach and national expansion plan are in `PROJECT_EXECUTION_PLAN.md`.

Core production requirements:
- National multi-tenant architecture covering schools across all 47 counties.
- Mandatory school access request and central Generali verification/approval before tenant provisioning.
- Parent/guardian Android app, school administration Android app, central Generali admin console and responsive web portal.
- Secure backend and PostgreSQL database with server-side role authorization and strict tenant isolation.
- KSh 20 platform subscription per registered parent/guardian account per school term, distinct from school fees and other school charges.
- Payment provider integration with signed server-side callbacks, idempotency, receipts and reconciliation.
- Independent security/privacy review, penetration testing, load testing, backup restoration and incident-response exercises.
- Controlled Gendia Boys High School pilot followed by measured county-by-county expansion.

**Release status:** Edition 3.2 is a branded front-end demonstration and planning package only. None of the production services above should be considered deployed or operational merely because they appear in the demo.
