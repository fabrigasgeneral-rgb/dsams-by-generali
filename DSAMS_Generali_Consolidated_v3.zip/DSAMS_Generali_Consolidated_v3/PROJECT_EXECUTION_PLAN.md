# DSAMS by Generali — National Project Execution Plan (Edition 3.2)

## Product mandate
DSAMS is intended as a Kenya-wide, multi-school digital platform serving schools across all 47 counties. Gendia Boys High School in Homa Bay County is the proposed first pilot site only; it is not the platform's national boundary and is not yet an onboarded or approved live customer.

The founder credit and portrait displayed on the landing page identify **General Fabrigas — Founder, DSAMS by Generali**. The image is used as a landing-page background and should be replaced only with the founder's approved updated image.

## Current release status — read carefully
Edition 3.2 is a front-end demonstration and project-planning package. It is not a fully functioning production service. No production Android app, live national database, real authentication, real school approval workflow, live payment collection, or completed independent security test is delivered in this ZIP. The visible browser interactions are demonstrations and may use local browser state.

## Target system components
1. **Parent/guardian Android app** — secure sign-in, guardian verification, learner linking, admission status, attendance, notices, CBE results, statements, termly DSAMS fee status, receipts and support.
2. **School administration Android app** — school-specific staff roles, admissions, learner records, attendance, CBE assessments, timetables/notices, school requirements, finance ledgers, reporting and controlled exports.
3. **Central Generali administration console** — nationwide school access request queue, official-school verification, approve/decline with reason, secure tenant provisioning, administrator invitations, school status controls, county-level monitoring, payment reconciliation, audit trail and support.
4. **Secure national backend and database** — one managed service with strict school tenant isolation, role-based access, encrypted storage/transport, backups, monitoring and disaster recovery.
5. **Payment service** — provider-hosted or approved mobile-money/card flow; verified server-to-server callbacks; receipts and reconciliation. Never collect or store a user's mobile-money PIN.
6. **Web portal** — accessible browser access for parents, school staff and central administrators, with the same server-side authorization as the mobile apps.

## Business rules to preserve
- A school must submit a formal access request to Generali. A school must not self-activate.
- Generali verifies the official school identity/code and the authority of the requesting representative before approving or declining.
- Approval triggers server-side tenant provisioning and an invitation to a verified school administrator. A demo button is not a real approval.
- The DSAMS platform fee is **KSh 20 per registered parent/guardian account per school term**, renewed each term. It is per parent account, not per learner, and separate from school fees and other school charges.
- Before payment launch, formally approve term dates, due dates, grace period, access treatment, exemptions, refunds, disputes, receipts, accounting, tax and disclosure.
- School data must remain isolated between schools. A parent may only see learners whose guardian relationship has been verified and authorized.
- Nationwide deployment requires county-wide support, training, accessibility, language and connectivity planning; the pilot must not be treated as evidence of national readiness.

## Recommended technical architecture
- Mobile: Android app built with Kotlin/Jetpack Compose or Flutter; select one after a technical proof of concept and maintenance assessment.
- Web: responsive web application for central administration and school workflows.
- Backend: versioned API with server-side authorization, validation, rate limits and audit events.
- Database: managed PostgreSQL with tenant identifiers, foreign keys, indexes, tenant-aware authorization and row-level security where suitable. Test cross-tenant access explicitly.
- Identity: reputable identity service, verified contact details, secure recovery and MFA for privileged users.
- Files: private object storage, malware scanning, short-lived signed access and retention rules.
- Operations: secrets manager, encrypted backups, tested restoration, monitoring, alerting, incident response and documented recovery objectives.
- Payments: integrate a licensed/approved payment provider using hosted checkout or provider SDK; verify signed callbacks on the server; use idempotency and reconciliation.

## Delivery stages and exit gates

### Stage 0 — Governance and discovery
- Confirm legal operating entity, project ownership, decision rights, support model and school contracts.
- Obtain written pilot interest/permission from Gendia Boys High School and identify authorized school contacts.
- Map actual admissions, learner records, attendance, CBE, fees, school charges and parent communication workflows.
- Agree data ownership, data-sharing roles, retention/deletion, consent/notice and complaints processes.
- Obtain Kenyan legal and data-protection advice; assess Data Protection Act obligations and whether a DPIA, registration or other approvals are required.
**Exit gate:** signed scope, process maps, responsibilities, privacy/legal review plan and pilot agreement.

### Stage 1 — Requirements and UX
- Produce approved user stories and acceptance criteria for each role.
- Prototype parent, school staff and Generali administrator journeys.
- Define offline/low-connectivity behaviour, accessibility, language and device support.
- Define the parent account and learner-linking rules, duplicate handling and account recovery.
**Exit gate:** requirements and screen flows signed off by representative users.

### Stage 2 — Core backend and administration
- Implement identity, roles, school tenants, school access requests and approval decisions.
- Implement tenant provisioning, school administrator invitations and suspension/reinstatement with audit logs.
- Implement parent/guardian accounts and verified guardian-learner relationships.
- Implement learner, admissions, attendance, CBE, notices, requirements and reporting modules.
- Implement distinct school-fees and other-school-charges ledgers.
**Exit gate:** automated tests pass; role and tenant-isolation tests pass; no demo-only controls remain in production.

### Stage 3 — Android and web applications
- Build parent Android app and school administration Android app.
- Build central Generali admin console and responsive web portal.
- Add secure notifications, receipt access, error handling and app update process.
- Test supported Android versions, low-memory devices, small screens and weak networks.
**Exit gate:** acceptance tests pass on agreed device matrix and accessibility review.

### Stage 4 — Payment integration
- Select and contract an appropriate payment provider; confirm fees, settlement, reversals and support.
- Implement KSh 20 per parent account per term as a separate platform subscription.
- Add signed webhook verification, duplicate-event protection, idempotency, receipts, refunds and reconciliation.
- Test success, failure, timeout, delayed callback, duplicate callback, reversal and disputed payment cases in sandbox.
**Exit gate:** finance reconciliation and security review signed off; no live charge until fee policy and disclosures are approved.

### Stage 5 — Security, privacy and resilience
- Threat-model account takeover, privilege escalation, cross-school data leakage, insecure exports, API abuse and payment manipulation.
- Conduct code review, dependency and secret scanning, static analysis, dynamic testing and independent penetration testing.
- Test tenant isolation, access controls, MFA, session expiry, password recovery, audit logging, encryption and backups.
- Run load, performance, recovery and incident-response exercises.
- Remediate critical/high findings and retest before pilot.
**Exit gate:** documented test report, remediation evidence, approved residual-risk register and go-live authorization.

### Stage 6 — Controlled Gendia pilot
- Confirm written participation and appoint school project lead and trained users.
- Use synthetic data in training; only use real learner data after legal/privacy controls and authorization are in place.
- Start with a small, agreed group; verify each parent account and guardian-learner link.
- Run admissions/records, attendance, CBE, communications and finance in parallel with existing approved school processes initially.
- Provide helpdesk, training, feedback capture, incident escalation and rollback plan.
- Review usability, accuracy, support demand, payment reconciliation and security logs weekly.
**Exit gate:** school acceptance, no unresolved critical/high security issue, reconciled payments, validated data quality and formal pilot evaluation.

### Stage 7 — County-by-county national scale
- Do not open nationwide self-registration. Retain central verification and approval for every school.
- Onboard in controlled waves with county support contacts and standardized training.
- Monitor capacity, uptime, incident rates, support backlog, data quality and payment settlement.
- Review each wave before adding more schools.
**Exit gate:** operational capacity and governance proven at each expansion stage.

## Minimum security test checklist
- A user from School A cannot view or modify School B records through UI, API, exports, guessed IDs or background jobs.
- A parent cannot access a learner without a verified guardian-learner link.
- School staff cannot perform actions outside their role or school.
- Only authorized Generali administrators with MFA can decide school requests or suspend tenants.
- Approval, decline, invitations, role changes, exports and sensitive access create tamper-evident audit events.
- Payment amount, parent, term and status are verified server-side; replayed or forged callbacks cannot create duplicate credits.
- Secrets and personal data are not exposed in logs, URLs, client bundles or error messages.
- Backup restoration, account recovery, rate limiting and incident response are tested.
- No production learner data is used in development/test environments unless specifically authorized and protected.

## Planning decisions still required
- Legal operator and formal contracting party.
- Final user roles and approval delegation within Generali.
- Official school verification source and acceptable evidence.
- Payment provider, settlement account, transaction fees and refund workflow.
- Term calendar, due date, grace period, exemptions and access rules for the KSh 20 fee.
- Hosting region, retention schedule, recovery objectives and support hours.
- Pilot cohort, device requirements, training dates and measurable success criteria.

## Pilot success measures
- School access requests processed with traceable decisions.
- Correct school and guardian account verification.
- Zero confirmed cross-tenant data exposure.
- Accurate learner, attendance and assessment records against approved school records.
- Payment reconciliation matches provider settlement and receipts.
- Parent and staff task completion, satisfaction and support resolution times meet agreed targets.
- No unresolved critical/high security findings at pilot go-live.
