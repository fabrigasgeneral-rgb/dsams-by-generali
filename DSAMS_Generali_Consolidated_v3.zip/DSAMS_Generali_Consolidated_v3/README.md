# DSAMS by Generali — Kenya National Edition 3.2

**Founder:** General Fabrigas  
**Scope:** Intended nationwide multi-school platform for all 47 counties in Kenya.  
**Proposed first pilot:** Gendia Boys High School, Homa Bay County, subject to written participation and onboarding approval.

## What this release contains
- `index.html` — updated front-page demonstration with the founder portrait and founder credit.
- `assets/founder-general-fabrigas.png` — image supplied for the landing-page background.
- `PROJECT_EXECUTION_PLAN.md` — staged plan for governance, backend, Android apps, payments, security testing, Gendia pilot and national rollout.
- `PRODUCTION_ROADMAP.md` — technical and release requirements.
- `DATA_MODEL.md` — proposed database entities and tenant boundaries.
- `legacy_versions/` — retained earlier project HTML versions.

## Important release status
This is **Edition 3.2: a branded demonstration and execution-planning package**, not a complete live system. It does not yet contain production Android applications, a live secure national database, real authentication, live school approval/provisioning, payment processing, completed security testing or an operational Gendia pilot. Browser interactions are demonstrations only. Do not enter real learner, guardian, staff, identity or payment information.

## Confirmed product rules
- Every school must request access from the central Generali administrator. Schools cannot self-activate.
- Generali must verify the school's identity and authorized representative before approving or declining.
- The DSAMS platform fee is **KSh 20 per registered parent/guardian account per school term**, renewed each term. It is per parent account, not per learner, and separate from school fees and other school charges.

## Open the demonstration
Extract the ZIP and open `index.html` in a modern browser. Keep the `assets` folder beside `index.html` so the founder background image loads.

## Next real-world work
Follow `PROJECT_EXECUTION_PLAN.md` in order. Production work requires an accountable development team, hosting and identity/payment provider decisions, formal school participation, legal/privacy review, testing, and deployment credentials. No live launch or payment collection should be attempted from this demo ZIP.
