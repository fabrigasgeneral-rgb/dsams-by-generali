# DSAMS by Generali — Production Multi-School Architecture Roadmap

## Product direction
**One platform. Multiple schools. One digital future.** Gendia Boys High School, Homa Bay County, remains the proposed pilot. DSAMS is designed to onboard eligible schools across all 47 counties in Kenya, subject to verification and approval by the DSAMS platform administration team.

## Multi-tenant model
- Each approved institution receives a unique, immutable `school_id` (tenant identifier).
- All school-owned records must carry that `school_id`: student profiles, guardians, admissions, staff, classes, attendance, assessments, fee schedules, invoices, payment references, stores catalogues, orders, notices and documents.
- A signed-in user receives access only through an active membership linking that user to a school and role.
- A user may belong to more than one school only when explicitly invited and approved for each school.
- The DSAMS platform owner can approve, suspend and support tenants. School administrators manage only their own school's users and settings.
- School selection in the public demo is not authentication and does not grant access to a tenant.

## School onboarding and approval
1. An authorised school representative submits official school name, county, category, level, registration reference (where applicable), and verified contact details.
2. The request enters a private central review queue.
3. DSAMS staff verify the institution and the authority of the requester using appropriate official evidence.
4. An approved request creates the school tenant and a pending first-administrator invitation.
5. The first administrator completes identity/contact verification and MFA setup.
6. The school configures its branding, academic year, classes, fee schedules, departments and stores catalogue.
7. Only after acceptance testing is the tenant enabled for real data.

## Roles and least privilege
- **Platform Owner:** platform-wide configuration, tenant approval/suspension, security oversight; sensitive access must be logged and limited.
- **School Administrator:** one school's profile, membership invitations and school configuration.
- **Admissions Officer:** admission applications and approved admission documents for assigned school.
- **Bursar / Finance Officer:** fee schedules, invoices, receipts and reconciliations for assigned school.
- **Teacher / Staff:** only assigned classes, learners and functions.
- **Stores Officer:** catalogue, inventory and orders for assigned school.
- **Parent / Guardian:** only learner records explicitly linked and verified to that guardian.
- **Student:** only permitted own-profile and learning information.

## Mandatory security architecture
1. **Authentication:** use a reputable identity provider; verified email/phone; secure session lifecycle; MFA for platform owners and school administrators; rate limiting and account recovery protections.
2. **Authorisation:** deny by default; check role, school membership, record ownership and assignment on every server request. Never trust a school ID, role, price, payment status or permission supplied by browser JavaScript.
3. **Tenant isolation:** enforce tenant boundaries in the database (for example, row-level security policies) and backend service layer. Every read, insert, update and delete must be scoped to the active authorised `school_id`. Test attempts to access another tenant's records.
4. **Secrets:** keep service keys, database credentials and payment secrets only in server-side secret storage. Never commit secrets into GitHub or frontend JavaScript. Rotate credentials and restrict privileges.
5. **Transport and storage:** HTTPS everywhere; encryption at rest; private object storage for documents; short-lived signed download links; malware/file-type/size checks; backups with restore tests.
6. **Audit:** append-only audit events for sign-ins, exports, record views where appropriate, changes to learner/finance records, role changes, approvals and administrative actions. Restrict audit-log access.
7. **Payments:** use an approved payment provider; create payment intents server-side; validate provider callbacks/signatures; reconcile against provider statements; use idempotency; never collect M-PESA PINs or card credentials in DSAMS.
8. **Operational security:** security monitoring, alerting, vulnerability/dependency updates, incident response, tested disaster recovery, rate limits, input validation, output encoding and regular penetration testing.
9. **Privacy:** collect only necessary information; define purpose and lawful basis; provide clear privacy notices; apply retention/deletion schedules; support data-subject requests; restrict children's data; assess cross-border transfers and processor contracts.

## Kenyan legal and governance work
Before processing real learner data, obtain qualified review of compliance with Kenya's Data Protection Act, 2019 and applicable regulations and guidance, including requirements relevant to children, education records, data processors/controllers, security safeguards, breach handling and any required registration or impact assessment. This roadmap is not legal advice or a compliance certification.

## Suggested production components
- Static web frontend hosted on a suitable CDN.
- Backend API with strict authentication and authorisation.
- Relational database with tenant-aware schema and database-enforced row policies.
- Private object storage for admission documents.
- Background job/notification service for email/SMS and school alerts.
- Approved payment gateway integration with server-side reconciliation.
- Central monitoring, audit log storage, backups and recovery process.

The technology vendor and deployment region should be selected after a security, privacy, cost, availability and data-residency review. Do not place a privileged database key in the public GitHub Pages site.

## Release gates before live use
- [ ] Backend and database deployed in a controlled environment.
- [ ] School onboarding queue is private and centrally approved.
- [ ] MFA, role permissions and tenant-scoped database policies are enabled.
- [ ] Automated tests prove School A cannot read or modify School B's data.
- [ ] Secure file upload/download and malware checks are enabled.
- [ ] Audit logging, backups, monitoring and incident response are tested.
- [ ] Payment integration is approved and reconciled server-side.
- [ ] Privacy notices, contracts, retention and impact assessment are reviewed.
- [ ] Independent security testing completed and critical findings fixed.
- [ ] Pilot runs with synthetic/test data before any real learner data is imported.

## Current package status
The included `index.html` is a public interactive demonstration. It adds a Kenya-wide school onboarding request demonstration and an in-product explanation of the intended multi-tenant architecture and security model. Its browser-local request list is not a real central registration system. Real accounts, school-separated databases, admissions submission, payment processing and secure records require the backend work above.
