# DSAMS by Generali — Kenya Multi-School Demonstration Update

## What's included
- `index.html`: integrated responsive front-end demo.
- `PRODUCTION_ROADMAP.md`: target multi-tenant architecture, security controls, rollout and production limitations.

## Publish this update to the existing GitHub Pages site
1. Download and extract this ZIP.
2. Open the existing repository `dsams-by-generali` on GitHub.
3. Replace the repository's existing root `index.html` with the `index.html` in this package.
4. Commit the replacement to the `main` branch.
5. Wait for GitHub Pages to finish deploying, then refresh the live site.

The package is prepared for the repository root. Keep the filename exactly `index.html`.

## Important production warning
This is a front-end demonstration, not a live multi-tenant school management service. The school request form stores sample entries in the visitor's browser only. It does not contact Generali, create school accounts, or transmit admissions. Dashboard, accounts, stores, and admission actions remain simulated. Do not enter real learner, parent, health, identity, or payment data.

GitHub Pages is static hosting. It cannot, by itself, provide secure server-side authentication, database row-level isolation, private document storage, trusted payment processing, or server-side audit logging. The production roadmap describes the backend work required before real schools are onboarded.
